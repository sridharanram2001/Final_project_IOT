
function updateData() {
    loadURL("http://localhost:3000/test", function (data) {
        const obj = JSON.parse(data);
        document.getElementById("results").innerHTML = JSON.stringify(obj.name);
        console.log(typeof data);
    })
}
function start() {
    
    let apple_temp = document.getElementsByClassName("apple")[0].innerHTML;
    
    var show_tag = document.getElementByClassName("show-apple")[0];

    show_tag.innerHTML += apple_temp

    setInterval("updateData()", 300);
}

